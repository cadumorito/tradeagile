function emailEnviado() {
    const email = document.getElementById('email').value;
    alert(`E-mail sent to: ${email}`);
}

function changePassword() {
    const email = document.getElementById('newPassword').value;
    alert(`Password changed successfully!`);
}